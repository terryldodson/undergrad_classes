//Terryl Dodson
//returns number of prime numbers within list
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <algorithm>
#include <list>
#include <iomanip>
using namespace std;

class isprime {
  public:
    isprime();
    bool operator()(int);
	bool prime_check(int);

  private:
    vector<int> primes;
	int max;
};

isprime::isprime() {
	primes.push_back(2);
	max = 2;
}

bool isprime::operator()(int number) {
	int i;
	if (number > max) {
		for(int i = max + 1; i <= number; i++)
			if(prime_check(i) == true)
				primes.push_back(i);
	}
	
	//performs binary search for number
	if(binary_search (primes.begin(), primes.end(), number))
		return true;
	else
		return false; 
}

bool isprime::prime_check(int number) {
	if(number <= 1)
        return false;

    for(int i = 2; i <= sqrt(number); i++) {
        if(number % i == 0)
            return false;
    }
    return true;	
}

int randNums() {
	return rand() % 140 + 1;
}

int main(int argc, char *argv[])
{
	isprime pcheck;
	int number;
	int N;

	if(argc != 2)
		N = 123;
	else
		N = atoi(argv[1]);

	srand(N);

	vector<int> nums(N);
	vector<bool> primes(N);
	
	//generates random numbers with num vector
	generate(nums.begin(), nums.end(), randNums);
	//inserts prime numbers from nums vector into prime vector
	transform(nums.begin(), nums.end(), primes.begin(), pcheck);
	
	//counts the number of prime numbers
	int nprimes = count(primes.begin(), primes.end(), true);

	cout << "Sequence contains " << nprimes << " prime numbers." << endl;
}
