//Terryl Dodson
//prints out prime numbers in list, then prints out prime numbers in sorted list with duplicates removed
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <algorithm>
#include <list>
#include <iomanip>
using namespace std;

class isprime {
  public:
    isprime();
    bool operator()(int);
	bool prime_check(int);

  private:
    vector<int> primes;
	int max;
};

isprime::isprime() {
	primes.push_back(2);
	max = 2;
}

bool isprime::operator()(int number) {
	int i;
	if (number > max) {
		for(int i = max + 1; i <= number; i++)
			if(prime_check(i) == true)
				primes.push_back(i);
	}

	if(binary_search (primes.begin(), primes.end(), number))
		return true;
	else
		return false; 
}

bool isprime::prime_check(int number) {
	if(number <= 1)
        return false;

    for(int i = 2; i <= sqrt(number); i++) {
        if(number % i == 0)
            return false;
    }
    return true;	
}

int randNums() {
	return rand() % 140 + 1;
}
//extracts the prime numbers and inserts them into the pnum vector (vector that only hold prime numbers)
vector<int> extract_prime(vector<int> nums, vector<bool> primes) {
	isprime pcheck;

	vector<int> pnums;

	for(int i = 0; i < nums.size(); i++) {
		if(primes[i] == true)
			pnums.push_back(nums[i]);
	}
	return pnums;
}

//prints out vector (8 numbers per line)
void print(vector<int> &pnums) {
	for(int i = 0; i < pnums.size(); i++) {
		if(i % 8 == 0)
			cout << endl;
		
		cout <<  " " << setw(3) << pnums[i];
	}

	cout << endl;
}

int main(int argc, char *argv[])
{
	isprime pcheck;
	int number;
	int N;

	if(argc != 2)
		N = 123;
	else
		N = atoi(argv[1]);

	srand(N);

	vector<int> nums(N);
	vector<bool> primes(N);

	generate(nums.begin(), nums.end(), randNums);
	transform(nums.begin(), nums.end(), primes.begin(), pcheck);
	
	int nprimes = count(primes.begin(), primes.end(), true);

	cout << "Sequence contains " << nprimes << " prime numbers." << endl;
	
	//prints out pnums vector
	vector<int> finalNums = extract_prime(nums, primes);
	cout << "All numbers in order appearance: ";
	print(finalNums);
	
	//prints out sorted vector with duplicates removed
	sort(finalNums.begin(), finalNums.end());
	finalNums.erase(unique(finalNums.begin(), finalNums.end()), finalNums.end());
	cout << "Unique values in numerical order: ";
	print(finalNums);
}
