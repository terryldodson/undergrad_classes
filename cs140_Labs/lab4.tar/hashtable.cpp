/*
 * INSTRUCTOR-GIVEN TEMPLATE (Clara)
 * COSC 140: Prog 4 - Hashtables
 *
 * Description:
 *     looks through a file and prints out the line number and line that contains the word
 *     that the user inputs
 * Author:
 *     Terryl Dodson, March 4, 2019
 */

#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <cctype>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string.h>
#include <iomanip>

using namespace std;

typedef unsigned int uint;

// ----------------------------------------------------------------------------
// Hash Table Prototype                                                    {{{1
// ----------------------------------------------------------------------------

class hash_table {
	public:
		hash_table(bool = false);
		~hash_table();
		void insert(const string &, unsigned int);
		const vector<int> &find(const string &);

	private:
		struct key_line {
			public:
				key_line();
				bool inuse();
				bool operator==(const string&);

				string key;
				vector<int> line_num;
		};

		int hash(const string &);
		int nextprime(int);
		int qprobe(const string &, bool = false);
		void resize();
		void print(vector<string> &);

		int num_inuse;
		int max_inuse;
		int collisions;
		int verbose;

		vector<key_line> table;
};

// ----------------------------------------------------------------------------
// Hash Table Function Implementations                                     {{{1
// ----------------------------------------------------------------------------

hash_table::key_line::key_line() { }

bool hash_table::key_line::inuse() { return (key != ""); }

hash_table::hash_table(bool b) {
	int N = 23;
	table.assign(N, key_line());

	num_inuse = 0; //number of slots
	max_inuse = N/2; // quadratic probe max value (max number of slots)
	collisions = 0; //number of collisions
	
	verbose = b;
}

hash_table::~hash_table() {
	if(verbose) {
		cout << endl;
		cout << "Run stats ... " << endl;
		cout << "Number of slots used: " << num_inuse  << endl;
		cout << "Max number of slots:  " << max_inuse << endl;
		cout << "Number of collisions: " << collisions << endl;
	}
}

void hash_table::insert(const string &key, unsigned int line) {
	int index = qprobe(key, true);

	if (!table[index].inuse()) {
		table[index].key = key;
		table[index].line_num.push_back(line);
		if (++num_inuse >= max_inuse)
			resize();
	}

	if(table[index].inuse() && table[index].key == key) {
		vector<int> &ref = table[index].line_num;
		if(std::find(ref.begin(), ref.end(), line) == ref.end())
			ref.push_back(line);
	}
}

int hash_table::hash(const string &key) {
	uint index = 0;
	const char *c = key.c_str();

	while (*c)
		index = ((index << 5) | (index >> 27)) + *c++;

	return index % table.size();
}

const vector<int> &hash_table::find(const string &key) {
	return table[qprobe(key)].line_num;
}

int hash_table::nextprime(int N) {
	int i = 2;
	while (i * i <= N) {
		if (N % i == 0) { N++; i = 1; }
		i++;
	}

	return max(3, N);
}

int hash_table::qprobe(const string &key, bool b) {
	int index = hash(key);

	int k = 0;
	while (table[index].inuse() && table[index].key != key) {
		index += 2 * (++k) - 1;
		index = index % table.size();

		if(b)
			collisions++;
	}


	return index;
}

void hash_table::resize() {
	vector<key_line> tmp_table;

	for (int i = 0; i < (int)table.size(); i++) {
		if (table[i].inuse())
			tmp_table.push_back(table[i]);
	}

	int N = nextprime(2 * table.size());
	table.assign(N, key_line());

	num_inuse = 0;
	max_inuse = N / 2;

	for (int i = 0; i < (int)tmp_table.size(); i++) {
		key_line &ref = tmp_table[i];
		table[ qprobe(tmp_table[i].key) ] = ref;
		num_inuse++;
	}
}

char replace_punctuation(const char& c) {
	if(ispunct(c))
		return ' ';
	else
		return c;
}

void print(vector<string> &cache) { 
	for(int i = 0; i < cache.size(); i++) 
		cout << " " << cache[i] << endl;
} 

//----------------------------------------------------------------------------
// Main Function                                                           {{{1
// ----------------------------------------------------------------------------

int main(int argc, char **argv) {

	unsigned int line;
	bool mode;

	vector<string> cache(1);
	string word, text;

	//checks arguments
	if (argc < 3 || (strcmp(argv[1], "-f") != 0 && strcmp(argv[1], "-vf") != 0)) {
        cerr << "Right usage is " << argv[0] << " -f | -vf filename" << endl;
	}

	//sets mode depending on argument
	if(strcmp(argv[1], "-f") == 0) 
		mode = 0;
	if(strcmp(argv[1], "-vf") == 0) 
		mode = 1;
	hash_table H(mode);
	
	//reads in file and calls it file (only read access only)
	ifstream file(argv[2]);
	
	//grabs each line and stores it in variable text
	//text is then added to the cache vector
	//next, punctuation is removed from the text in cache vector and stored into text vector
	//then we scan each word in text vector and insert in the hashtable
	for(line = 1; getline(file, text); line++) {
		cache.push_back(text);
		transform(text.begin(), text.end(), text.begin(), replace_punctuation);
		stringstream scan(text);
		
		while(scan >> word) {
			H.insert(word,line);
		}
	}
	
	//searches for word that user types
	//if found, it prints out the line number and the line
     while(cout << "find> " && cin >> word) {
		 const vector<int> &stuff = H.find(word); //vector hold line numbers that contain the word word
            for(int i = 0; i < stuff.size(); i++) {
                cout << stuff[i] << ": " << cache[stuff[i]] << endl;
            }
        }
	
	 //closes file
	 file.close();

}
