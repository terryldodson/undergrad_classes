//Terryl Dodson
//February 7th, 2019
//CS140: Lab 2b

#include <cstdlib>
#include <iostream>
#include <sstream>
#include <iomanip>

using namespace std;

const string face[] = { "Ace", "2", "3", "4", "5", "6", "7",
                        "8", "9", "10", "Jack", "Queen", "King" }; 
const string suit[] = { "Spades", "Hearts", "Diamonds", "Clubs" };

class list {
	private:
		struct node {
			int index;
			node(int value = -1) {
				index = value; 
				next = NULL; 
			}
			node *next;
		};

	public:
		list();
		~list();
		void insert(int);

		friend ostream& operator<<(ostream &, const list &);

	private: 
		node *head;
		int N;
};

list::list() {
	head = new node;
	N = 0;
}

list::~list() {
	delete head;
}

void list::insert(int value) {
	//insert at the front of the list
	//Go down the list, and if this is another node with the same value then annihilate it
		node *p;  
		node *prev;
	
		node *din;
		din = new node(value);

		//inserts new node
        din->next = head->next;
        head->next = din;
        
		N++;

		din = head->next;

		int count = N - 1;
		while(count--) {
			if(din->next->index == value) {
            	prev = din->next;
				din->next = din->next->next;
				delete prev;
				
				N--;
				break;
			}
			else {
				din = din->next;
			}
		}
}

//revises the output to print the faces of the cards
ostream & operator <<(ostream &of, const list &l) {
	list::node *p = l.head->next;

	while(p) {
		of << " " << face[p->index]; 
		p = p->next;
	}
	return of;
}

string random_card(bool verbose=false) {
	string card;

	card = face[ rand()%13 ];
	card += " of ";
	card += suit[ rand()%4 ];

	if (verbose)
	  cout << card << "\n";

	return card;
}

int main(int argc, char *argv[])
{
	bool verbose = false;
	int seedvalue = 0;

	//create a table with 4 rows and 13 columns
	int table[4][13];

	list deck[4];

	//set all of "table" to 0
	for(int i = 0; i < 4; i++)
		for(int j = 0; j < 13; j++)
			table[i][j] = 0;

	for (int i=1; i<argc; i++) {
	  string option = argv[i];
	  if (option.compare(0,6,"-seed=") == 0) {
	    seedvalue = atoi(&argv[i][6]);
	  } else if (option.compare("-verbose") == 0) {
	    verbose = true;
	  } else 
	    cout << "option " << argv[i] << " ignored\n";
	}

	srand(seedvalue);

	// declare a table that can keep track of the
	// cards dealt for each suit -- initialize to 0
	
	int prevadded;

	while (1) {
	  string card = random_card(verbose);

	  string myface, mysuit;

	  //card = "Ace of Spades"
	  istringstream ss;
	  ss.str(card);

	  ss >> myface >> mysuit >> mysuit;
	  
	  // reverse engineer card suit and face (value)
	  
	  //if the random card equals the face and suit and another card, it increments that cell and sets the rows value in prevadded
	  int i, j;
	  for(i = 0; i < 4; i++)
		  for(j = 0; j < 13; j++)
			  if(myface == face[j] && mysuit == suit[i]) {
				table[i][j]++;
				deck[i].insert(j);
				prevadded = i;
			  }

	  // update accordingly: table[suit][value]++
      // break out of loop if stopping criteria met
	  //
	  // breaks ouut if King, Queen, and Jack are greater than or equal to 2
	  if(table[prevadded][10] >= 2 && table[prevadded][11] >= 2 && table[prevadded][12] >= 2)
		  break;
	}

	// print formatted table contents to stdout 
	for(int i = 0; i < 4; i++) {
		cout << setw(8) << suit[i] << ":" << deck[i];
		if(prevadded == i)
			cout << " **";
		cout << endl;
	}
}
