#   author:     Terryl Dodson
#   file:       main.py
#   description:
#       this file implements the starter code for Project 1.
#
#   requirements:
#       this file assumes that the 'breast-cancer-wisconsin.data' is
#       located in the same directory
#
#   resources used for building this starter file
#   - https://bradfieldcs.com/algos/trees/representing-a-tree/
import csv
import math

def calculate_entropy(data):
    total_benign = 0
    total_malignant = 0
    overall_total = 0

    # calculates total number of benign and malignant values
    for i in range(0, len(data)):
        overall_total += 1
        if int(data[i][10]) == 2:
            total_benign += 1
        elif int(data[i][10]) == 4:
            total_malignant += 1

    if total_benign == 0 or total_malignant == 0:
        entropy = 0
    else:
        # calculates entropy
        entropy = -(total_benign/overall_total) * math.log2(total_benign/overall_total) - \
            (total_malignant/overall_total) * \
            math.log2(total_malignant/overall_total)

    return round(entropy, 4)


def calculate_midpoint(data, feature):
    benign_list = []
    malignant_list = []
    benign_group_mean = []
    malignant_group_mean = []

    total_benign = 0
    total_malignant = 0
    overall_total = 0

    # calculates total number of benign and malignant values
    for i in range(0, len(data)):
        overall_total += 1
        if int(data[i][10]) == 2:
            total_benign += 1
        elif int(data[i][10]) == 4:
            total_malignant += 1

    # separates the two classes (list for 2's and 4's)
    for i in range(0, len(data)):
        if int(data[i][10]) == 2:
            benign_list.append(data[i])
        elif int(data[i][10]) == 4:
            malignant_list.append(data[i])

    # stores benign values in one list and malignant ones in the other for the specific feature
    for i in range(len(benign_list)):
        benign_group_mean.append(benign_list[i][feature])

    for i in range(len(malignant_list)):
        malignant_group_mean.append(malignant_list[i][feature])

    benign_values_sum = 0
    malignant_values_sum = 0

    # calculates sum of both benign and malignant ucs values
    for i in range(len(benign_group_mean)):
        benign_values_sum += float(benign_group_mean[i])

    for i in range(len(malignant_group_mean)):
        malignant_values_sum += float(malignant_group_mean[i])

    benign_values_average = 0
    malignant_values_average = 0

    if benign_values_sum == 0 or len(benign_group_mean) == 0:
        benign_values_average = 0
    elif malignant_values_sum == 0 or len(malignant_group_mean) == 0:
        malignant_values_average = 0
    else:
        # calculates average of both benign and malignant ucs values
      
        benign_values_average = round(
            benign_values_sum / len(benign_group_mean), 1)
        malignant_values_average = round(
            malignant_values_sum / len(malignant_group_mean), 1)

    # calculates splitting criteria
    mean_of_two_groups = round(
        (benign_values_average + malignant_values_average) / 2, 1)
    print('splitting > ', mean_of_two_groups)

    return mean_of_two_groups


def acquireSplit(data, feature, ig_values):

    left_ben = []
    left_mal = []
    right_ben = []
    right_mal = []

    benign = []
    malignant = []
    overall_total = 0

    entropy = calculate_entropy(data)

    split_value = calculate_midpoint(data, feature)

    # calculated total number of benigns and malignants
    for i in range(0, len(data)):
        overall_total += 1
        if int(data[i][10]) == 2:
            benign.append(data[i])
        elif int(data[i][10]) == 4:
            malignant.append(data[i])

    # executed split and found out how many was benign/non-benign
    for i in range(0, len(benign)):
        if float(data[i][feature]) >= split_value:
            left_ben.append(data[i])
        else:
            right_ben.append(data[i])

    # executed split and found out how many was malignant/non-malignant
    for i in range(0, len(malignant)):
        if float(data[i][feature]) >= split_value:
            left_mal.append(data[i])
        else:
            right_mal.append(data[i])

    if int(len(right_ben + right_mal)) == 0:
        conditional_entropy = 0

    if int(len(left_mal)) != 0 and int(len(left_ben)) != 0 and int(len(right_mal)) != 0 and int(len(right_ben)) != 0:

        conditional_entropy = (len(left_ben + left_mal)/overall_total) * ((-len(left_ben)/len(left_ben + left_mal)) * math.log2(len(left_ben) /
                                                                                                                                len(left_ben + left_mal)) - (len(left_mal)/len(left_ben + left_mal)) * math.log2(len(left_mal)/len(left_ben + left_mal)))
        + (len(right_ben + right_mal)/overall_total) * ((-len(right_ben)/len(right_ben + right_mal)) * math.log2(len(right_ben) /
                                                                                                                 len(right_ben + right_mal)) - (len(right_mal)/len(right_ben + right_mal)) * math.log2(len(right_mal)/len(right_ben + right_mal)))

    elif int(len(right_ben)) == 0 or int(len(right_mal)) == 0:

        if int(len(left_mal)) != 0 and int(len(left_ben)) == 0 and int(len(right_mal)) == 0 and int(len(right_ben)) == 0:
            conditional_entropy = 0

        else:
            if int(len(left_mal)) == 0 and int(len(left_ben)) == 0 and int(len(right_mal)) == 0 and int(len(right_ben)) == 0:
                conditional_entropy = 0
            
            else: 
                conditional_entropy = (len(left_ben + left_mal)/overall_total) * ((-len(left_ben)/len(left_ben + left_mal)) * math.log2(len(left_ben) /
                                                                                                                                        len(left_ben + left_mal)) - (len(left_mal)/len(left_ben + left_mal)) * math.log2(len(left_mal)/len(left_ben + left_mal)))
            

    elif int(len(left_ben)) == 0 or int(len(left_mal)) == 0:

        conditional_entropy = (len(right_ben + right_mal)/overall_total) * ((-len(right_ben)/len(right_ben + right_mal)) * math.log2(len(right_ben) /
                                                                                                                                     len(right_ben + right_mal)) - (len(right_mal)/len(right_ben + right_mal)) * math.log2(len(right_mal)/len(right_ben + right_mal)))

                                                                                                                       
    else:
        conditional_entropy = 0

    ig = entropy - conditional_entropy

    ig_values.append(round(ig, 4))

    return ig_values, entropy, conditional_entropy, left_mal, left_ben, right_mal, right_ben


def executeSplit(data, threshold):

    ig_values = []

    left_ben = []
    left_mal = []
    right_ben = []
    right_mal = []

    benign = []
    malignant = []

    for feature in range(1, 10):
        ig_values, entropy, conditional_entropy, left_mal, left_ben, right_mal, right_ben = acquireSplit(
            data, feature, ig_values)

    print(entropy)
    print(ig_values)
    split_feature = ig_values.index(max(ig_values))
    split_value = max(ig_values)
    print('split feature: ', split_feature, ' split_value: ', split_value)

    newNode = InternalNode(split_feature, split_value)
    print('internal node')
    
    if max(ig_values) >= threshold:
        print('leaf node')
        # calculated total number of benigns and malignants
        for i in range(0, len(data)):
            if int(data[i][10]) == 2:
                benign.append(data[i])
            elif int(data[i][10]) == 4:
                malignant.append(data[i])

            if len(benign) > len(malignant):
                return LeafNode(2)
            else:
                return LeafNode(4)

    elif entropy == 0:
        print('leaf node 1')
        if int(len(data)) != 0:
            if int(data[0][10]) == 2:
                return LeafNode(2)
            else:
                return LeafNode(4)
    elif conditional_entropy == 0:
        print('leaf node 2')
        if(int(data[0][10]) == 2):
            return LeafNode(2)
        else:
            return LeafNode(4)

    if not isinstance(newNode, LeafNode):
        left = executeSplit(left_ben + left_mal, threshold)
        newNode.insert_left(left)

        right = executeSplit(right_ben + right_mal, threshold)
        newNode.insert_right(right)

    return newNode


class InternalNode(object):
    # An Internal Node class that has an associated feature and criteria for splitting.
    def __init__(self, feature, criteria):  # Constructor
        self.type = type
        self.feature = feature
        self.criteria = criteria
        self.left = None
        self.right = None

    def insert_left(self, child):
        if self.left is None:
            self.left = child
        else:
            child.left = self.left
            self.left = child

    def insert_right(self, child):
        if self.right is None:
            self.right = child
        else:
            child.right = self.right
            self.right = child

    def get_depth(self, iter):
        # Recursively return the depth of the node.
        l_depth = self.get_depth(iter+1)
        r_depth = self.get_depth(iter+1)

        # return the highest of the two
        return max([l_depth, r_depth])


class LeafNode(object):
    # A Leaf Node class that has an associated decision.
    def __init__(self, decision):  # Constructor
        self.decision = decision

    def retreiveDecision(self, child):
        return self.decision

    def get_depth(self, iter):
        return iter


class DecisionTreeBuilder:
    '''This is a Python class named DecisionTreeBuilder.'''

    def __init__(self):  # Constructor
        self.tree = None  # Define a ``tree'' instance variable.

    def construct(self, data, threshold=0.2):
        '''
           This function constructs your tree with a default threshold of None. 
           The depth of the constructed tree is returned.
        '''

        # As a starting place, we are statically setting our tree to a root node
        # with two children. This code does not reflect a correct approach as it
        # does not build the tree from the data. (See Decision Trees II Slides.)

        root = executeSplit(data, threshold)

        self.tree = root
        return self.tree.get_depth(0)  # Return the depth of your constructed tree.'''

    def classify(self, data):
        '''
           This function classifies data with your tree. 
           The predictions for the given data are returned.
        '''
        # Use the constructed tree here., e.g. self.tree

        # Return a list of predictions.
        # Note: This list should be built dynamically.
        return [2, 2, 4, 2, 3, 4]


# 1. Read in data from file.
print("1. Reading File")
with open("breast-cancer-wisconsin.data") as fp:
    reader = csv.reader(fp, delimiter=",", quotechar='"')
    # Uncomment the following line if the first line in your CSV is column names
    # next(reader, None)  # skip the headers

    # create a list (i.e. array) where each index is a row of the CSV file.
    all_data = [row for row in reader]
print()

# 2. Split the data into training and test sets.
#   Note: This is an example split that simply takes the first 90% of the
#    data read in as training data and uses the remaining 10% as test data.
print("2. Separating Data")
number_of_rows = len(all_data)  # Get the length of our list.
training_data = all_data
test_data = all_data[:]         #
print()

# 3. Create an instance of the DecisionTreeBuilder class.
print("3. Instantiating DecisionTreeBuilder")
dtb = DecisionTreeBuilder()
print()

# 4. Construct the Tree.
print("4. Constructing the Tree with Training Data")
tree_length = dtb.construct(training_data)
print("Tree Length: " + str(tree_length))
print()

# 5. Classify Test Data using the Tree.
print("5. Classifying Test Data with the Constructed Tree")
predictions = dtb.classify(test_data)
print()

print("-- List of Predictions --")
if(len(predictions) > 0):
    for idx, prediction in enumerate(predictions):
        print("Prediction #" + str(idx) + ': ' + str(prediction))
else:
    print(' : Predictions list is empty.')
