import numpy as np
import pandas as pd
import pylab as pl
import seaborn as sns
import csv
from sklearn import svm, datasets
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split 
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from datetime import datetime

# By default, Sklearn forces warnings into your terminal.
# Here, we're writing a dummy function that overwrites the function
# that prints out numerical warnings.
# (You probably don't want to do this in any of your projects!)
def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn

#####################################################################
# SETTING 2: Terrain Classification for Multispectrcal Pixel Values.
#####################################################################

train_url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/statlog/satimage/sat.trn'
train_df = pd.read_csv(train_url, names=np.arange(0,37), delim_whitespace=True)
features = np.arange(0,2)
x_train = train_df.loc[:, features].values
y_train = train_df.loc[:, [36]].values
scaler1 = MinMaxScaler(feature_range=(0, 1))
x_train = scaler1.fit_transform(x_train)

test_url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/statlog/satimage/sat.tst'
test_df = pd.read_csv(test_url, names=np.arange(0,37), delim_whitespace=True)
features = np.arange(0,2)
x_test = train_df.loc[:, features].values
y_test = train_df.loc[:, [36]].values
scaler1 = MinMaxScaler(feature_range=(0, 1))
x_test = scaler1.fit_transform(x_test)

# Now, we create several instances of SVCs that utilize varying kernels.
# We're not normalizing our data here because we want to plot the support vectors.
svc     = svm.SVC(kernel='linear').fit(x_train, y_train)
poly_svc_one = svm.SVC(kernel='linear', C=10).fit(x_train, y_train)
poly_svc_two = svm.SVC(kernel='linear', C=100000).fit(x_train, y_train)
poly_svc_three = svm.SVC(kernel='linear', C=10000).fit(x_train, y_train)
rbf_svc_one = svm.SVC(kernel='linear', C=100).fit(x_train, y_train)
rbf_svc_two = svm.SVC(kernel='linear', C=1000).fit(x_train, y_train)
rbf_svc_three = svm.SVC(kernel='linear', C=1).fit(x_train, y_train)
#rbf_svc_four = svm.SVC(kernel='rbf', C=100, gamma=0.5).fit(x_train, y_train)

# Now, we run our test data through our trained models.
predicted_linear = svc.predict(x_test)
predicted_poly_one = poly_svc_one.predict(x_test)
predicted_poly_two = poly_svc_two.predict(x_test)
predicted_poly_three = poly_svc_three.predict(x_test)
predicted_rbf_one = rbf_svc_one.predict(x_test)
predicted_rbf_two = rbf_svc_two.predict(x_test)
predicted_rbf_three = rbf_svc_three.predict(x_test)
#predicted_rbf_four = rbf_svc_four.predict(x_test)

# Print our accuracies.
print("SVM + Linear           \t\t-> " + str(accuracy_score(y_test, predicted_linear)))
print("SVM + Linear (C=10)      \t-> " + str(accuracy_score(y_test, predicted_poly_one)))
print("SVM + Linear (C=100000)  \t-> " + str(accuracy_score(y_test, predicted_poly_two)))
print("SVM + Linear (C=10000)   \t-> " + str(accuracy_score(y_test, predicted_poly_three)))
print("SVM + Linear (C=100)     \t-> " + str(accuracy_score(y_test, predicted_rbf_one)))
print("SVM + Linear (C=1000)    \t-> " + str(accuracy_score(y_test, predicted_rbf_two)))
print("SVM + Linear (C=1)       \t-> " + str(accuracy_score(y_test, predicted_rbf_three)))
#print("SVM + RBF-100/0.5 \t-> " + str(accuracy_score(y_test, predicted_rbf_four)))

'''# # # # # # # # # # # # #
# PLOTTING CODE STARTS  #
# # # # # # # # # # # # #

# create a mesh to plot in
h=.02 # step size in the mesh
x_min, x_max = features[0].min()-1, features[0].max()+1
y_min, y_max = features[1].min()-1, features[1].max()+1
xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                     np.arange(y_min, y_max, h))
                     
#title for the plots
titles = ['SVC with linear kernel',
          'Linear (C=10)',
          'Linear (C=100000)',
          'Linear (C=10000)',
          'Linear (C=100)',
          'Linear (C=1000)',
          'Linear (C=1)']
          #'Poly (C=1000; D=3)']


# If we wanted to set a color scheme for our plot, we could do so here.
# For example:
#   pl.set_cmap(pl.cm.Accent)

for i, clf in enumerate((svc, poly_svc_one, poly_svc_two, poly_svc_three, rbf_svc_one, rbf_svc_two, rbf_svc_three)): #, rbf_svc_four)):
    # Plot the decision boundary. For that, we will asign a color to each
    # point in the mesh [x_min, m_max]x[y_min, y_max].
    pl.subplot(2, 4, i+1)
    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])

    # Put the result into a color plot
    Z = Z.reshape(xx.shape)

    #pl.set_cmap(pl.cm.Accent)
    
    # Apply 
    pl.contourf(xx, yy, Z)

    pl.axis('tight')

    # Plot also the training points
    pl.scatter(x_train[features[0]], x_train[features[1]], edgecolor='black')
    #c = y_train,

    pl.title(titles[i])

pl.axis('tight')
pl.show()

# # # # # # # # # # # # #
# PLOTTING CODE Ends  #
# # # # # # # # # # # # #'''

'''# # # # # # # # # # # # # # # # # # # # #
# Coarse Grid Search                    #
#   - Broad sweep of hyperparemeters.   #
# # # # # # # # # # # # # # # # # # # # #
print()
starttime = datetime.now()
print('start time: ', starttime)

print()
print('Coarse Grid Search')
print('---------------------------------')
# Set the parameters by cross-validation
tuned_parameters = [
    {
        'kernel': ['linear'], 
        'C': [1, 10, 100, 1000]
    },
    {
        'kernel': ['poly'], 
        'degree': [2, 3, 4],
        'C': [1, 10, 100, 1000]
    },
    {
        'kernel': ['rbf'], 
        'gamma': [1e-3, 1e-4],
        'C': [1, 10, 100, 1000]
    }
]


scores = ['precision', 'recall']

for score in scores:
    print("# Tuning hyper-parameters for %s" % score)
    print()

    clf = GridSearchCV(
        SVC(), tuned_parameters, scoring='%s_macro' % score
    )
    clf.fit(x_train, y_train)

    print("Best parameters set found on development set:")
    print()
    print(clf.best_params_)
    print()
    print("Grid scores on development set:")
    print()
    means = clf.cv_results_['mean_test_score']
    stds = clf.cv_results_['std_test_score']
    for mean, std, params in zip(means, stds, clf.cv_results_['params']):
        print("%0.3f (+/-%0.03f) for %r"
              % (mean, std * 2, params))
    print()

    print("Detailed classification report:")
    print()
    print("The model is trained on the full development set.")
    print("The scores are computed on the full evaluation set.")
    print()
    y_true, y_pred = y_test, clf.predict(x_test)
    print(classification_report(y_true, y_pred))
    print()

endtime = datetime.now()
print('end time: ', endtime)'''

'''# # # # # # # # # # # # # # # # # # # # # # #  #
# Fine Grid Search                             #
#   - More focused sweep of hyperparemeters.   #
# # # # # # # # # # # # # # # # # # # # # # #  #

print('Fine Grid Search')
print('---------------------------------')

# Set the parameters by cross-validation
tuned_parameters = [
    {
        'kernel': ['linear'], 
        'C': [1, 10, 100, 1000, 10000, 100000]
    },
]


scores = ['precision', 'recall']

for score in scores:
    print("# Tuning hyper-parameters for %s" % score)
    print()

    clf = GridSearchCV(
        SVC(), tuned_parameters, scoring='%s_macro' % score
    )
    clf.fit(x_train, y_train)

    print("Best parameters set found on development set:")
    print()
    print(clf.best_params_)
    print()
    print("Grid scores on development set:")
    print()
    means = clf.cv_results_['mean_test_score']
    stds = clf.cv_results_['std_test_score']
    for mean, std, params in zip(means, stds, clf.cv_results_['params']):
        print("%0.3f (+/-%0.03f) for %r"
              % (mean, std * 2, params))
    print()

    print("Detailed classification report:")
    print()
    print("The model is trained on the full development set.")
    print("The scores are computed on the full evaluation set.")
    print()
    y_true, y_pred = y_test, clf.predict(x_test)
    print(classification_report(y_true, y_pred))
    print()'''