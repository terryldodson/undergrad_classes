import numpy as np
import pandas as pd
import pylab as pl
import seaborn as sns
from sklearn import svm, datasets
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split 
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn.svm import SVC
from sklearn.decomposition import PCA

# By default, Sklearn forces warnings into your terminal.
# Here, we're writing a dummy function that overwrites the function
# that prints out numerical warnings.
# (You probably don't want to do this in any of your projects!)
def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn

#####################################################################
# SETTING 1: Predicting Good/Bad Interactions of Radar Signals.
#####################################################################

#reading in provided data
data = pd.read_csv('ionosphere.data.csv')

A1 = data['A1'].values
A2 = data['A2'].values
A3 = data['A3'].values
A4 = data['A4'].values
A5 = data['A5'].values
A6 = data['A6'].values
A7 = data['A7'].values
A8 = data['A8'].values
A9 = data['A9'].values
A10 = data['A10'].values
A11 = data['A11'].values
A12 = data['A12'].values
A13 = data['A13'].values
A14 = data['A14'].values
A15 = data['A15'].values
A16 = data['A16'].values
A17 = data['A17'].values
A18 = data['A18'].values
A19 = data['A19'].values
A20 = data['A20'].values
A21 = data['A21'].values
A22 = data['A22'].values
A23 = data['A23'].values
A24 = data['A24'].values
A25 = data['A25'].values
A26 = data['A26'].values
A27 = data['A27'].values
A28 = data['A28'].values
A29 = data['A29'].values
A30 = data['A30'].values
A31 = data['A31'].values
A32 = data['A32'].values
A33 = data['A33'].values
A34 = data['A34'].values
target = data['target'].values
new_target = []

for i in target:
    #1 is good and 0 is bad
    if i == 'g':
        new_target.append(1)
    else:
        new_target.append(0)

#features = np.array([A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12,A13,A14,A15,A16,A17,A18,A19,A20,A21,A22,A23,A24,A25,A26,A27,A28,A29,A30,A31,A32,A33,A34]).T

features = np.array([A2,A3]).T

X = features
Y = np.array(new_target)

scaler1 = MinMaxScaler(feature_range=(0, 1))
rescaledX = scaler1.fit_transform(X)

# Use Sklearn to get splits in our data for training and testing.
x_train, x_test, y_train, y_test = train_test_split(rescaledX, Y, test_size=0.8, random_state=0)
y_train_converted = y_train.ravel()

# Now, we create several instances of SVCs that utilize varying kernels.
# We're not normalizing our data here because we want to plot the support vectors.
svc     = svm.SVC(kernel='linear').fit(x_train, y_train)
poly_svc_one = svm.SVC(kernel='linear', C=100).fit(x_train, y_train_converted)
poly_svc_two = svm.SVC(kernel='linear', C=1000).fit(x_train, y_train_converted)
poly_svc_three = svm.SVC(kernel='linear', C=10000).fit(x_train, y_train_converted)
rbf_svc_one = svm.SVC(kernel='linear', C=100000).fit(x_train, y_train_converted)
rbf_svc_two = svm.SVC(kernel='linear', C=10).fit(x_train, y_train_converted)
rbf_svc_three = svm.SVC(kernel='linear', C=1).fit(x_train, y_train_converted)
#rbf_svc_four = svm.SVC(kernel='poly', C=1000, degree=3).fit(x_train, y_train_converted)

# Now, we run our test data through our trained models.
predicted_linear = svc.predict(x_test)
predicted_poly_one = poly_svc_one.predict(x_test)
predicted_poly_two = poly_svc_two.predict(x_test)
predicted_poly_three = poly_svc_three.predict(x_test)
predicted_rbf_one = rbf_svc_one.predict(x_test)
predicted_rbf_two = rbf_svc_two.predict(x_test)
predicted_rbf_three = rbf_svc_three.predict(x_test)
#predicted_rbf_four = rbf_svc_four.predict(x_test)

# Print our accuracies.
print("SVM + Linear          \t\t-> " + str(accuracy_score(y_test, predicted_linear)))
print("SVM + Linear (C=100)    \t-> " + str(accuracy_score(y_test, predicted_poly_one)))
print("SVM + Linear (C=1000)   \t-> " + str(accuracy_score(y_test, predicted_poly_two)))
print("SVM + Linear (C=10000)  \t-> " + str(accuracy_score(y_test, predicted_poly_three)))
print("SVM + Linear (C=100000) \t-> " + str(accuracy_score(y_test, predicted_rbf_one)))
print("SVM + Linear (C=10)     \t-> " + str(accuracy_score(y_test, predicted_rbf_two)))
print("SVM + Linear (C=1)      \t-> " + str(accuracy_score(y_test, predicted_rbf_three)))
#print("SVM + RBF-100/0.5 \t-> " + str(accuracy_score(y_test, predicted_rbf_four)))

'''# # # # # # # # # # # # #
# PLOTTING CODE STARTS  #
# # # # # # # # # # # # #

# create a mesh to plot in
h=.02 # step size in the mesh
x_min, x_max = A2.min()-1, A2.max()+1
y_min, y_max = A3.min()-1, A3.max()+1
xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                     np.arange(y_min, y_max, h))
                     
#title for the plots
titles = ['SVC with linear kernel',
          'Linear (C=100)',
          'Linear (C=1000)',
          'Linear (C=10000)',
          'Linear (C=100000)',
          'Linear (C=10)',
          'Linear (C=1)']
          #'Poly (C=1000; D=3)']


# If we wanted to set a color scheme for our plot, we could do so here.
# For example:
#   pl.set_cmap(pl.cm.Accent)

for i, clf in enumerate((svc, poly_svc_one, poly_svc_two, poly_svc_three, rbf_svc_one, rbf_svc_two, rbf_svc_three)): #, rbf_svc_four)):
    # Plot the decision boundary. For that, we will asign a color to each
    # point in the mesh [x_min, m_max]x[y_min, y_max].
    pl.subplot(2, 4, i+1)
    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])

    # Put the result into a color plot
    Z = Z.reshape(xx.shape)

    #pl.set_cmap(pl.cm.Accent)
    
    # Apply 
    pl.contourf(xx, yy, Z)

    pl.axis('tight')

    # Plot also the training points
    pl.scatter(A2, A3, c = target, edgecolor='black')
    #c=Y['target'], 

    pl.title(titles[i])

pl.axis('tight')
pl.show()

# # # # # # # # # # # # #
# PLOTTING CODE Ends  #
# # # # # # # # # # # # #'''

# # # # # # # # # # # # # # # # # # # # #
# Coarse Grid Search                    #
#   - Broad sweep of hyperparemeters.   #
# # # # # # # # # # # # # # # # # # # # #

print()
print('Coarse Grid Search')
print('---------------------------------')
# Set the parameters by cross-validation
tuned_parameters = [
    {
        'kernel': ['linear'], 
        'C': [1, 10, 100, 1000]
    },
    {
        'kernel': ['poly'], 
        'degree': [2, 3, 4],
        'C': [1, 10, 100, 1000]
    },
    {
        'kernel': ['rbf'], 
        'gamma': [1e-3, 1e-4],
        'C': [1, 10, 100, 1000]
    }
]


scores = ['precision', 'recall']

for score in scores:
    print("# Tuning hyper-parameters for %s" % score)
    print()

    clf = GridSearchCV(
        SVC(), tuned_parameters, scoring='%s_macro' % score
    )
    clf.fit(x_train, y_train)

    print("Best parameters set found on development set:")
    print()
    print(clf.best_params_)
    print()
    print("Grid scores on development set:")
    print()
    means = clf.cv_results_['mean_test_score']
    stds = clf.cv_results_['std_test_score']
    for mean, std, params in zip(means, stds, clf.cv_results_['params']):
        print("%0.3f (+/-%0.03f) for %r"
              % (mean, std * 2, params))
    print()

    print("Detailed classification report:")
    print()
    print("The model is trained on the full development set.")
    print("The scores are computed on the full evaluation set.")
    print()
    y_true, y_pred = y_test, clf.predict(x_test)
    print(classification_report(y_true, y_pred))
    print()

# # # # # # # # # # # # # # # # # # # # # # #  #
# Fine Grid Search                             #
#   - More focused sweep of hyperparemeters.   #
# # # # # # # # # # # # # # # # # # # # # # #  #

print('Fine Grid Search')
print('---------------------------------')

# Set the parameters by cross-validation
tuned_parameters = [
    {
        'kernel': ['poly'], 
        'degree': [1, 2, 3, 4, 5, 6],
        'C': [1, 10, 100, 1000, 10000]
    },
    {
        'kernel': ['linear'], 
        'C': [1, 10, 100, 1000, 10000, 100000]
    }
]


scores = ['precision', 'recall']

for score in scores:
    print("# Tuning hyper-parameters for %s" % score)
    print()

    clf = GridSearchCV(
        SVC(), tuned_parameters, scoring='%s_macro' % score
    )
    clf.fit(x_train, y_train)

    print("Best parameters set found on development set:")
    print()
    print(clf.best_params_)
    print()
    print("Grid scores on development set:")
    print()
    means = clf.cv_results_['mean_test_score']
    stds = clf.cv_results_['std_test_score']
    for mean, std, params in zip(means, stds, clf.cv_results_['params']):
        print("%0.3f (+/-%0.03f) for %r"
              % (mean, std * 2, params))
    print()

    print("Detailed classification report:")
    print()
    print("The model is trained on the full development set.")
    print("The scores are computed on the full evaluation set.")
    print()
    y_true, y_pred = y_test, clf.predict(x_test)
    print(classification_report(y_true, y_pred))
    print()