#include <iostream>
#include <string>
#include <climits>
using namespace std;

class stats {
	public:
		stats();
		void push(int);
		void print();
	private:
		int value;
    	int count;
    	int sum;
    	int min;
    	int max;
};

int main(int argc, char *argv[]) {
	stats s;
	int value;

	while(cin >> value) {
		s.push(value);
	}

	s.print();
}

stats::stats() {
	value = 0;
	count = 0;
	sum = 0;
	min = INT_MAX;
	max = INT_MIN;
}

void stats::print() {
	 cout << "N = " << count << "\n";
     cout << "sum = " << sum << "\n";
     cout << "min = " << min << "\n";
     cout << "max = " << max << "\n";
}

void stats::push(int v) {
	sum += v;
    if(v < min)
        min = v;
    else if(v > max)
        max = v;
    count++;	
}
