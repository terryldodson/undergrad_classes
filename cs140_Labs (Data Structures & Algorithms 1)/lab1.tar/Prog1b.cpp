#include <iomanip>
#include <iostream>
#include <climits>
using namespace std;

int main(int argc, char *argv[]) {
	int value;
	int count;
	int sum;
	int min = INT_MAX;
	int max = INT_MIN;

	while(cin >> value) {
		sum += value;
		if(value < min)
			min = value;
		else if(value > max)
			max = value;
		count++;
	}

	 cout << "N = " << count << "\n";
	 cout << "sum = " << sum << "\n";
	 cout << "min = " << min << "\n";
	 cout << "max = " << max << "\n";

}
