//Terryl Dodson
//Checks to see if number is a prime number, only for the numbers greater than max
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <algorithm>
using namespace std;

class isprime {
  public:
    isprime();
    bool operator()(int);
	bool prime_check(int);

  private:
    vector<int> primes;
	int max;
};

isprime::isprime() {
	primes.push_back(2);
	max = 2;
}

bool isprime::operator()(int number) {
	int i;
	if (number > max) {
		for(int i = max + 1; i <= number; i++)
			if(prime_check(i) == true)
				primes.push_back(i);
	}

	vector<int>::iterator i1;
	i1 = find(primes.begin(), primes.end(), number);

	if(i1 == primes.end())
		return false;
	else
		return true;
}

bool isprime::prime_check(int number) {
	if(number <= 1)
        return false;

    for(int i = 2; i <= sqrt(number); i++) {
        if(number % i == 0)
            return false;
    }
    return true;	
}

int main()
{
	isprime pcheck;
	int number;

	while (cin >> number) {
	  if (pcheck(number))
	    cout << number << " is a prime number" << endl;
	}
}
