//Terryl Dodson
//Binary Search Tree
//Description: Printed out right and left node for each node, printed 
//out nodes in inorder, and found the lower and upper bound of a given node
#ifndef BST_H
#define BST_H

#include <iomanip>
#include <iostream>
#include <queue>
#include <vector>
using namespace std;

template <class TKey>
class bst {
	struct node {
		node(int = 0);

		void print();

		TKey key;
		//ID parameter
		int id;

		node *parent;
		node *left;
		node *right;
	};

	public:
		class iterator {
			public:
				iterator();
				
				//operator overloads
				iterator& operator++();
				TKey & operator* ();
				bool  operator==(const iterator &);
				bool  operator!=(const iterator &);
				
				//default constructor (no arguments)
				//overloaded operators (++, *, ==, !=)
			private:
				friend class bst<TKey>;
				//constructor (with argument)
				iterator(node *);

				node *p;
	   };

	   iterator begin();
	   iterator end() {return iterator(NULL);}

	public:
	bst() { Troot=NULL; next_id = 1;}
	~bst() { clear(Troot); }

	bool empty() { return Troot==NULL; }

	void insert(TKey &);

	iterator lower_bound(const TKey &);
	iterator upper_bound(const TKey &);

	void print_bylevel();

	private:
	void clear(node *);
	node *insert(node *, TKey &);

	//ID parameter
	int next_id;
	node *Troot;
};

//bst<TKey>::node constructor goes here

template<class TKey>
bst<TKey>::node::node(int ID) {
	id = ID;
	//set your other pointers to NULL
	parent = NULL;
	left = NULL;
	right = NULL;
}

	template <class TKey>
void bst<TKey>::node::print()
{
	cout << setw(3) << key << " " << setw(3) << id << " :";

	 if (parent)
        cout << " P=" << setw(3) << parent->id;
    else
        cout << " ROOT ";

	//output node and parent ID information
	//change below to output subtree ID information

	if (left)  
		cout << " L=" << setw(3) << left->id;
	else       
		cout << "      ";
	if (right) 
		cout << " R=" << setw(3) << right->id;
	else       
		cout << "      ";

	cout << "\n";
}

//bst<TKey>::iterator functions not defined above go here

template <class TKey>
void bst<TKey>::clear(node *T)
{
	if (T) {
		clear(T->left);
		clear(T->right);
		delete T;
		T = NULL;
	}
}

template <class TKey>
typename bst<TKey>::iterator bst<TKey>::begin() {
	iterator o;
	o.p = Troot;

	while(o.p->left)
		o.p = o.p->left;

	return o;
}

template <class TKey>
bst<TKey>::iterator::iterator() {
	
}

template <class TKey>
bst<TKey>::iterator::iterator(node * n) {
	p = n;
}

template <class TKey>
bool bst<TKey>::iterator::operator!=(const iterator &rhs) {
	return p != rhs.p;
}

template <class TKey>
bool bst<TKey>::iterator::operator==(const iterator &rhs) {
	return p == rhs.p;
}

template <class TKey>
TKey & bst<TKey>::iterator::operator*() {
	return p->key;
}

template <class TKey>
typename bst<TKey>::iterator &bst<TKey>::iterator::operator++() {
	//go to right once, if done go left as many times as possible
	if(p->right) {
		p = p->right;
		while(p->left) {
			p = p->left;
		}
	}

	else {
		node* prev;

		while(true) {
			prev = p;
			p = p->parent;
			//if we came from the left we're done
			//if we come from the right, go up until we come from the left
			if (p == NULL)
				break;

			if(p->left == prev)
				break;
			//if we reach the root from the right, set the iterator to NULL			
			if(p->parent == NULL && p->right == prev) {
				p = NULL;
				break;
			}

		}	
	}
	
	return *this;
}

template <class TKey>
void bst<TKey>::insert(TKey &key)
{ 
	Troot = insert(Troot, key);
}

template <class TKey>
class bst<TKey>::node *bst<TKey>::insert(node *T, TKey &key)
{
	//set parent link below

		if (T == NULL) {
			//update and set node ID 
			T = new node(next_id++);
			T->key = key;
		} else if (T->key == key) {
			;
		} else if (key < T->key) {
			T->left = insert(T->left, key);
			//set the parent here
			T->left->parent = T;
		} else {
			T->right = insert(T->right, key);
			//set the parent here
			T->right->parent = T;
		}

	return T;
}

//bst<TKey>::lower_bound function goes here
template <class TKey>
typename bst<TKey>::iterator bst<TKey>::lower_bound(const TKey &key) {
	node* p;
	node* check = NULL;

	p = Troot;

		while(p != NULL) {
			if(key <= p->key) {
				check = p;
				p = p->left;
			}

			else{
				p = p->right;
			}
		}
		return check;
}  

//bst<TKey>::upper_bound function goes here
template <class TKey>
typename bst<TKey>::iterator bst<TKey>::upper_bound(const TKey &key) {
	node* p;
	node* check = NULL;

	p = Troot;

		while(p != NULL) {
			if(key < p->key) {
				check = p;
				p = p->left;
			}

			else{
				p = p->right;
			}
		}
		return check;
} 

template <class TKey>
void bst<TKey>::print_bylevel()
{
	if (Troot == NULL)
		return;

	queue<node *> Q;
	node *T;

	Q.push(Troot);
	while (!Q.empty()) {
		T = Q.front();
		Q.pop();

		T->print();
		if (T->left)  Q.push(T->left);
		if (T->right) Q.push(T->right);
	}
}

#endif
