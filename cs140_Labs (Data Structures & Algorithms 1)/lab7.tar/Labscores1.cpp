#include <vector>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <string>
#include <iomanip>
#include <fstream>
#include <map>
#include <string.h>
#include <numeric>

using namespace std;
typedef float SCORE_T;

class name_t {
	public:
	name_t();
	name_t(const string &, const string &);

	bool operator < (const name_t &) const;

	void print_name(size_t) const;

	private:

	string first, last; 
};

class labscores_t {
	public:
	//Object lifetime Handlers
	labscores_t();

	//Modifiers
	void add_data(const SCORE_T &);
	void set_stats();
	void print_labscores() const;

	private:
		vector<SCORE_T> scores;
		SCORE_T median;
		SCORE_T average;
};

name_t::name_t() {
	first = "";
	last = "";
}

name_t::name_t(const string& T, const string& D) {
	first = T;
	last = D;
}

bool name_t::operator < (const name_t & p) const{
	if(last == p.last)
		return first < p.first;

	return last < p.last;
}

void name_t::print_name(size_t len) const { //size_t is length of longest name
	string concat = last + ", " + first + " ";

	cout << left << setw(len + 3) << setfill('.') << concat << ".. ";
}

void labscores_t::add_data(const SCORE_T & info) {
	scores.push_back(info);
}

void labscores_t::set_stats() {
	float sum = accumulate(scores.begin(), scores.end(), 0);
	sort(scores.begin(), scores.end());

	average = sum / scores.size();
	median = scores[(scores.size() - 1) / 2] ;
}

void labscores_t::print_labscores() const {
	for(int i = 0; i < scores.size(); i++) {
		printf("%2d ",  (int) scores[i]);
	}

	//cout << ": " << median << " " << fixed << setprecision(1) << average << resetiosflags(std::cout.flags()) << endl;
	printf(": %2d %.1f\n", (int) median, average);
}

labscores_t::labscores_t() {
	median = 0;
	average = 0;
}

int main(int argc, char *argv[]) {
	if(argc != 3) {
		cerr << "3 arguments please\n";
		return 1;
	}

	string line;
	string n1, n2;
	int m;
	int len = 0;
	map<name_t, labscores_t> data;

	ifstream fp;
	fp.open(argv[2]);

	while(getline(fp, line)) {
		istringstream isis;
		isis.clear();
		isis.str(line);

		//inserts into map
		labscores_t b;


		//read in the first string
		isis >> n1;

		//read in the second string
		isis >> n2;

		if(len < n1.size() + n2.size())
			len = n1.size() + n2.size();


		//creates name with first and last name
		name_t a(n1, n2);
	
		//read in numbers
		while(isis >> m) {
			//cout << m << endl;
			b.add_data(m);
		}

		data[a] = b;
	}

	fp.close();

	map<name_t, labscores_t>::iterator i1;
	for(i1 = data.begin(); i1 != data.end(); i1++) {
		i1->second.set_stats();
		i1->first.print_name(len);
		i1->second.print_labscores();
	}
	
}
