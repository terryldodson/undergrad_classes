#include <vector>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <string>
#include <iomanip>
#include <fstream>
#include <map>
#include <string.h>
#include <numeric>

using namespace std;
typedef float SCORE_T;

class name_t {
	public:
	name_t();
	name_t(const string &, const string &);

	bool operator < (const name_t &) const;

	void print_name(size_t) const;

	private:

	string first, last; 
};//end of name_t class

class labscores_t {
	public:
	//Object lifetime Handlers
	labscores_t();

	//Modifiers
	void add_data(const SCORE_T &);
	void set_stats();
	void print_labscores() const;

	private:
		vector<SCORE_T> scores;
		friend class heap_t;
		SCORE_T median;
		SCORE_T average;
};//end of labscores_t class

class heap_t { 
	struct data_t{
		data_t();
		data_t(map<name_t, labscores_t>::iterator p) {d = p;}
		bool operator <(const data_t &) const;
		map<name_t, labscores_t>::iterator d;
	};
	
	public:
		
		bool empty();
		friend class name_t;
		friend class labscores_t;

		void add_data(const map<name_t, labscores_t>::iterator&);
		void heapify();
		map<name_t,labscores_t>::iterator extract_top();

	private:
		vector<data_t> heap;
};//end of heap_t class

name_t::name_t() {
	first = "";
	last = "";
}//end of constructor

name_t::name_t(const string& T, const string& D) {
	first = T;
	last = D;
}//end of name_t constructor

//sorts lists according to name
bool name_t::operator < (const name_t & p) const{
	if(last == p.last)
		return first < p.first;

	return last < p.last;
} //end of operator overload

//format for printing out names
void name_t::print_name(size_t len) const { //size_t is length of longest name
	string concat = last + ", " + first + " ";

	cout << left << setw(len + 3) << setfill('.') << concat << ".. ";
}//end of print name

//adds labscores to vector
void labscores_t::add_data(const SCORE_T & info) {
	scores.push_back(info);
} //end of add data

//sorts the data and find the average and median
void labscores_t::set_stats() {
	float sum = accumulate(scores.begin(), scores.end(), 0);
	sort(scores.begin(), scores.end());

	average = sum / scores.size();
	median = scores[(scores.size() - 1) / 2] ;
} //end of set stats

//format for printing out labscores
void labscores_t::print_labscores() const {
	for(int i = 0; i < scores.size(); i++) {
		printf("%2d ",  (int) scores[i]);
	} //end of for

	//cout << ": " << median << " " << fixed << setprecision(1) << average << resetiosflags(std::cout.flags()) << endl;
	printf(": %2d %.1f\n", (int) median, average);
}//end of print_labscores

labscores_t::labscores_t() {
	median = 0;
	average = 0;
}//end of labscores constructor

//returns true if heap is empty
bool heap_t::empty() {
	if(heap.size() == 0)
		return true;

	return false;
}//end of empty

void heap_t::add_data(const map<name_t, labscores_t>::iterator& c) {
	heap.push_back(data_t(c));
}//end of add_data

//sorts list according to average, if averages are the same then sort them according to the median
//if the median are the same, then sort them according to name
bool heap_t::data_t::operator < (const data_t & p) const {
	if(p.d->second.average != d->second.average)
		return d->second.average < p.d->second.average;
	
	if(p.d->second.median != d->second.median)
		return d->second.median < p.d->second.median;

	return p.d->first < d->first;
}//end of operator overlaod

//creates the heap
void heap_t::heapify() {
	make_heap(heap.begin(), heap.end());	
}//end of heapify

//retreives the max element on the heap
map<name_t, labscores_t>::iterator heap_t::extract_top() {
	data_t data = heap.front();
	pop_heap(heap.begin(), heap.end());
	heap.pop_back();

	return data.d;
} //end of extract top

int main(int argc, char *argv[]) {
	if(argc != 3) {
		cerr << "3 arguments please\n";
		return 1;
	} //end of if

	string line;
	string n1, n2;
	int m;
	int len = 0;
	map<name_t, labscores_t> data;

	ifstream fp;
	fp.open(argv[2]);

	while(getline(fp, line)) {
		istringstream isis;
		isis.clear();
		isis.str(line);

		//inserts into map
		labscores_t b;


		//read in the first string
		isis >> n1;

		//read in the second string
		isis >> n2;

		if(len < n1.size() + n2.size())
			len = n1.size() + n2.size();


		//creates name with first and last name
		name_t a(n1, n2);
	
		//read in numbers
		while(isis >> m) {
			//cout << m << endl;
			b.add_data(m);
		} //end of while

		data[a] = b;
	}//end of while

	fp.close();

	//prints out according to the name
	if(strcmp(argv[1], "-byname") == 0) {
		map<name_t, labscores_t>::iterator i1;
		for(i1 = data.begin(); i1 != data.end(); i1++) {
			i1->second.set_stats();
			i1->first.print_name(len);
			i1->second.print_labscores();
		} //end of for
	} //end of if

	//prints out the list byrank
	else if(strcmp(argv[1], "-top10") == 0 || strcmp(argv[1], "-byrank") == 0) {
		heap_t heap;
		map<name_t, labscores_t>::iterator i2;
		for(i2 = data.begin(); i2 != data.end(); i2++) {
			i2->second.set_stats();
			heap.add_data(i2);
		} //end of for

		heap.heapify();
		
		//only prints out the top 10 for top10
		if(strcmp(argv[1], "-top10") == 0) {
			for(int i = 0; i < 10; i++) {
				i2 = heap.extract_top();
				i2->second.set_stats();
				i2->first.print_name(len);
				i2->second.print_labscores();
			} //end of for
		}//end of if

		//if its not top10 then print out like usual
		else {
			while(!(heap.empty())) {
			  i2 = heap.extract_top();
		      i2->first.print_name(len);
			  i2->second.print_labscores();
			} //end of while
		}//end of else	
	} //end of else if
}//end of main

