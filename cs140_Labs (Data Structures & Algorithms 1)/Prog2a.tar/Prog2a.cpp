#include <cstdlib>
#include <iostream>
#include <sstream>
#include <iomanip>

using namespace std;

const string face[] = { "Ace", "2", "3", "4", "5", "6", "7",
                        "8", "9", "10", "Jack", "Queen", "King" }; 
const string suit[] = { "Spades", "Hearts", "Diamonds", "Clubs" };

string random_card(bool verbose=false) {
	string card;

	card = face[ rand()%13 ];
	card += " of ";
	card += suit[ rand()%4 ];

	if (verbose)
	  cout << card << "\n";

	return card;
}

int main(int argc, char *argv[])
{
	bool verbose = false;
	int seedvalue = 0;

	//create a table with 4 rows and 13 columns
	int table[4][13];

	//set all of "table" to 0
	for(int i = 0; i < 4; i++)
		for(int j = 0; j < 13; j++)
			table[i][j] = 0;

	for (int i=1; i<argc; i++) {
	  string option = argv[i];
	  if (option.compare(0,6,"-seed=") == 0) {
	    seedvalue = atoi(&argv[i][6]);
	  } else if (option.compare("-verbose") == 0) {
	    verbose = true;
	  } else 
	    cout << "option " << argv[i] << " ignored\n";
	}

	srand(seedvalue);

	// declare a table that can keep track of the
	// cards dealt for each suit -- initialize to 0
	
	int prevadded;

	while (1) {
	  string card = random_card(verbose);

	  string myface, mysuit;

	  //card = "Ace of Spades"
	  istringstream ss;
	  ss.str(card);

	  ss >> myface >> mysuit >> mysuit;
	  
	  // reverse engineer card suit and face (value)
	  
	  //if the random card equals the face and suit and another card, it increments that cell and sets the rows value in prevadded
	  int i, j;
	  for(i = 0; i < 4; i++)
		  for(j = 0; j < 13; j++)
			  if(myface == face[j] && mysuit == suit[i]) {
				table[i][j]++;
				prevadded = i;
			  }

	  // update accordingly: table[suit][value]++
      // break out of loop if stopping criteria met
	  //
	  // breaks ouut if King, Queen, and Jack are greater than or equal to 2
	  if(table[prevadded][10] >= 2 && table[prevadded][11] >= 2 && table[prevadded][12] >= 2)
		  break;
	}

	// print formatted table contents to stdout 
	for(int i = 0; i < 4; i++) {
		cout << setw(8) << suit[i] << ":";
		for(int j = 0; j < 13; j++) {
			cout << setw(4) << table[i][j];
		}
		if(prevadded == i)
			cout << " **";
		cout << endl;
	}
}
