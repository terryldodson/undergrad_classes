#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <fstream>
#include <vector>
#include <unistd.h>
using namespace std;

class sudoku {
  public:
	sudoku();

	void solve();

    void read(const char *);
    void write(const char *);
    void write(const char *, const char *);

  private:
    int solve(uint, uint);

    // various support functions 
    void error_check_value();
    void error_check_uniqueness();

	bool check_row(uint, uint = 0);
	bool check_col(uint , uint = 0);
	bool check_square(uint, uint);

    void display();

	void valid_values(uint, uint, vector<int> &);

    int game[9][9];
};

sudoku::sudoku() { 
  for (int i=0; i<9; i++) {
    for (int j=0; j<9; j++)
      game[i][j] = 0;
  }
}

void sudoku::solve() {
  cout << "SOLVE\n";

  // call recursive computation
  uint i, j;
  for(i = 0; i < 9; i++) {
	for(j = 0; j < 9; j++) {
		if(game[i][j] == 0) {
			//call recursive computation (break bcuz you only want to call solve on the first 0)
			solve(i, j);
			break;
		}

	}
	//that previous loop was broken out of
	if(j != 9)
		break;
  }
	
  display();

	//check others
	// error check data values
	// error check uniqueness
	// exit if errors detected
	error_check_value();
	error_check_uniqueness();
}

void sudoku::error_check_value() {
	bool check = false;
	int line = 1;

	for(int i = 0; i < 9; i++) {
		for(int j = 0;  j < 9; j++) {
			if(game[i][j] < 0 || game[i][j] > 9) {
				 check = true;
				 fprintf(stderr, "cell %d %d: out-of-bounds data value %d\n", i, j, game[i][j]);
			}
		}
	}

	if(check)
		exit(0);

}

void sudoku::error_check_uniqueness() {
	bool check = false;
	
	for(int i = 0; i < 9; i++) {
		for(int j = 0; j < 9; j++) {
			if (game[i][j] == 0)
				continue;
			bool col = check_col(i, j);
			bool row = check_row(i, j);
			bool square = check_square(i, j);
			
			if(col || row || square) {
				fprintf(stderr, "cell %d %d: non-unique value %d\n", i, j, game[i][j]);
				check = true;
			}
		}
	}

	if (check)
		exit(0);
}

//i is row and j is the value
bool sudoku::check_row(uint i, uint j) {
	bool rowcheck = false;
	int count = 0;

    if(game[i][j] != 0) {
	//check uniqueness in rows
		for(int m = 0; m < 9; m++) {
			if(game[i][j] == game[m][j])
				count++;
		}

	}
	return count > 1;
	return rowcheck;
}

//i is col and j is value
bool sudoku::check_col(uint i, uint j) {
	bool colcheck = false;

    if(game[i][j] != 0) {
    //Check uniqueness in cols
		for(int k = 0; k < 9; k++) {
            if(k != j && game[i][k]==game[i][j])
                colcheck = true;
        }
    }
	return colcheck;
}

bool sudoku::check_square(uint i, uint j) {
	bool squarecheck = false;
	int srow = (i / 3) * 3;
	int scol = (j / 3) * 3;
    
    if(game[i][j] != 0) {
    //check uniqueness in square
        for(int l = srow; l < srow+3; l++) {
            for(int n = scol; n < scol+3; n++) {
                if(!(i == l && j == n) && game[i][j] == game[l][n])
                    squarecheck = true;
                }
            }
    }   
    return squarecheck;
}

void sudoku::read(const char *fname) {
  cout << "READ\n";
  bool check = false;
  int line = 1;

  ifstream fin(fname);
    
  int i, j, v;

  while (fin >> i >> j >> v) {
    // error check grid indices
	// exit if bad grid indices
	//if(!(i > 0 && i < 9 && j > 0 && j < 9)) {
	if (i < 0 || i > 8 || j < 0 || j > 8) {
		check = true;
		fprintf(stderr, "line %d: %d %d %d out-of-bounds grid index \n", line, i, j, v);
	}
	else
		game[i][j] = v;

	line++;
  }


  if(check)
	  exit(0);

  fin.close();

  display();

  //error check data values
  //error check uniqueness
  //exit if errors detected
   error_check_value();
   error_check_uniqueness();
}

void sudoku::write(const char *fname) {
  ofstream fout(fname);

  for (int i=0; i<9; i++) {
    for (int j=0; j<9; j++) {
      if (0 < game[i][j]) {
        fout << i << " "
			 << j << " "
		     << game[i][j] << "\n";
      }
    }
  }

  fout.close();
}

void sudoku::write(const char *fname, const char *addon) {
  int N1 = strlen(fname);
  int N2 = strlen(addon);

  char *n_fname = new char[N1+N2+2];

  // strip .txt suffix, then concatenate _addon.txt
  strncpy(n_fname, fname, N1-4);
  strcpy(n_fname+N1-4, "_");
  strcpy(n_fname+N1-3, addon);
  strcpy(n_fname+N1-3+N2, ".txt");

  write(n_fname);

  delete [] n_fname;
}

void sudoku::display() {
  cout << "| --------------------------- |\n";
  for (int i=0; i<9; i++) {
    for (int j=0; j<9; j++) {
	  if (j == 0) 
	    cout << "| " << game[i][j];
	  else if (j%3 == 0) 
	    cout << " | " << game[i][j];
	  else
	    cout << "  " << game[i][j];
	}
    cout << " |\n";
	if (i%3 == 2)
      cout << "| --------------------------- |\n";
  }
}

void sudoku::valid_values(uint a, uint b, vector<int> &values) { //a is row number and b is col number
	//add valid integers for each row to values vector
	for(int i = 1; i <= 9; i++) {
		game[a][b] = i;
		if(!(check_row(a, b) || check_col(a, b) || check_square(a, b)))
			values.push_back(i);
	}	
	game[a][b] = 0;
}

int sudoku::solve(uint row, uint col) {
	uint i, j, k, sz;

	vector<int> valid;
	valid_values(row, col, valid);
	sz = valid.size();

	for(i = 0; i < sz; i++) {
		game[row][col] = valid[i];
	
	//find the next cell to put the values in
  
		for(j = row; j < 9; j++) {
			if(j != row)
				k = 0;
			else
				k = col + 1;
			
			for(; k < 9; k++) {
				if(game[j][k] == 0) {
					if(solve(j,k))
						return 1;
					break;
				}

			}

			if(k != 9)
				break;
		}

		if(j == 9 && k == 9)
			return 1;
	}

	game[row][col] = 0;
  
	return 0;
}

int main(int argc, char *argv[]) {
  srand(time(NULL));

  if ((argc != 3) ||
      (strcmp(argv[1], "-s") != 0) ||
	  strstr(argv[argc-1], ".txt") == NULL) {
    cerr << "usage: Sudoku -s game.txt\n";
	exit(0);
  }

  sudoku sudoku_game;

  if (strcmp(argv[1], "-s") == 0) {
    sudoku_game.read(argv[2]);
    sudoku_game.solve();
    sudoku_game.write(argv[2], "solved");
  }
}
