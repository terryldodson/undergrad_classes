#include <iostream>
using namespace std;

int strlen(char *); 

int main(int argc, char *argv[]) {
	cout << "Num args = " << argc << "\n";
	for(int i = 0; i < argc; i++) {
		string name;
		name = argv[i];
		cout << "argv[" << i << "] = " << &argv[i] << " " << name << " (strlen=" << strlen(argv[i]) << ")" << "\n";
	}
}

int strlen(char *string) {
	int length=0;
    while(*string != '\0' ){
        length++;
        string++;
    }
    return length;	
}
