list::node *list::findnode(int i) {
	if(i == -1)
		return head;

	node *p = head->next;
	int j;

	if(i < N/2) {
		for(j = 0; j != i; j++) {
			p = p->next;
		}
	}
	
	else {
		for(j = N+1; j != i; j--) {
			p = p->prev;
		}
	}

	return p;
}
