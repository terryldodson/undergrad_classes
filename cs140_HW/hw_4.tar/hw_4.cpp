class stack {
	stack();
	~stack();
	bool empty();
	int size();
	void push();
	void pop();
	const data_t & top();
}

stack::stack() {
	N = 0;
	Nmax = 10;
	front_index = 0;
	back_index = -1;
	data = new data_t[Nmax];
}

stack::~stack() {
	delete [] data;
}

bool stack::empty() {
	return N == 0;
}

int stack::size() {
	return N;
}

void stack::push() {
	if(++back_index == Nmax)
		back_index = 0;

	data[back_index] = din;

	N++;
}

void stack::pop() {
	if(++front_index == Nmax)
		front_index = 0;

	N--;
}

const data_t & top() { 
	return data[front_index];
}
