#Terryl Dodson
#CS425 Project 2
#Description: Find a best fit line for the provided data that will predict mpg values
import numpy as np
import pandas as pd
import math
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
import seaborn as sns

#from writeup
def r2_score(Y, Y_pred):
    '''Produces the R2 score between two NumPy arrays.'''
    mean_y = np.mean(Y)
    ss_tot = sum((Y - mean_y) ** 2)
    ss_res = sum((Y - Y_pred) ** 2)
    r2 = 1 - (ss_res / ss_tot)
    return r2

#used a combination of the kaggle website (https://www.kaggle.com/rakend/multiple-linear-regression-with-gradient-descent)
#and the following youtube video (https://www.youtube.com/watch?v=vsWrXfO3wWw)
def GD(x, y, alpha, m):
    # x is the feature vector
    # y is correct mpg values
    # m is the weights

    size = 392
    i = 1
    new_y = []
    cost_list = []

    #while loop for iterations and calculating the predicted_y (dot product)
    #also calculated loss and inserted into cost_list
    while i < 300000:
        predicted_y = np.dot(x, m)
        new_y.append(predicted_y)

        #loss = (1/size) * np.sum(np.square(predicted_y-y))
        error = predicted_y-y
        loss = 1/(2*size) * np.dot(error.T, error)
        cost_list.append(loss)

        #updates weights
        m = m - (alpha * (1/size) * np.dot(x.T, error))

        #increments
        i += 1

    #calls r2 and prints r2 value
    #print('r2: ', r2_score(y, predicted_y))

    return predicted_y, cost_list, m


#creating a list of the features I would like to extract
col_list = ["cylinders", "displacement",
            "horsepower", "weight", "acceleration", "year", "origin"]

#reading in provided data
data = pd.read_csv("auto-mpg.csv")


# separate the values from each column by column name
mpg = data['mpg'].values
cylinders = data['cylinders'].values
disp = data['displacement'].values
hp = data['horsepower'].values
weight = data['weight'].values
acc = data['acceleration'].values
yr = data['year'].values
orig = data['origin'].values

#creates the array of ones
m = len(mpg)
x0 = np.ones(m)

# create an array of all features , i.e. X values , and transpose it
X = np.array([x0, cylinders, disp, hp, weight, acc, yr, orig]).T

# initialize coefficients/weights
B = np.zeros(8)

# create an array for given mpg values
Y = np.array(mpg)

# establish a learning rate (non-normalized and normalized)
alpha = 0.0000001
alpha1 = 0.001

#implementing standardization
scaler1 = MinMaxScaler(feature_range=(0, 1))
rescaledX = scaler1.fit_transform(X)

#calling the gradient descent function (non-normalized)
predicted_y, cost_list, m = GD(X, Y, alpha, B)
#calling the gradient descent function (normalized)
#predicted_y, cost_list, m = GD(rescaledX, Y, alpha1, B)
predicted_y = np.around(predicted_y)

print('Weights: ')
print(m)

print('')
print('Predicted mpg values: ')
print(predicted_y)

print('')
print('Actual mpg values: ')
print(Y)

'''
#plots the line graphs
sns.lineplot(x='origin', y='mpg', data=data).set_title('Origin vs MPG')

#plotting 7 features using mpg as y
sns.pairplot(data=data, y_vars=['mpg'], x_vars=col_list)
plt.show()

# obtained code from kaggle website (https://www.kaggle.com/rakend/multiple-linear-regression-with-gradient-descent)
#plotting the cost function
plt.title('Cost Function', size = 30)
plt.xlabel('No. of iterations', size=20)
plt.ylabel('Cost', size=20)
plt.plot(cost_list)
plt.show()'''
