#include <iostream>
#include <list>
using namespace std;

template <typename T>
class ex_eq {
	public:
		ex_eq(const T &n_target) {
			target = n_target;
		}

		bool operator() (const T &v) const {
			return v == target;
		}
	private:
		T target;
};

template <typename iT, typename Func>
int ex_count(iT i1, iT i2, Func function);

int main() {
    list<int> v;
    list<int>::iterator iv;
    int value;

    while (cin >> value)
        v.push_back(value);

    int target = *v.begin();
    int N = ex_count(v.begin(), v.end(), ex_eq<int>(target));

    cout << "Found " << N << " instances of " << target << "\n";
}

template <typename iT, typename Func>
int ex_count(iT i1, iT i2, Func function) {
  int count = 0;
  iT itr;

  for(itr = i1; itr != i2; itr++)
	  count += function(*itr);

  return count;
}

