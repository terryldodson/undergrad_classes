#include <iostream>
#include <string>
#include <climits>
using namespace std;

template <typename T>
class stats {
    public:
        stats();
        void push(T);
		void print();
    private:
        T value;
        int count;
		T sum;
};

int main(int argc, char *argv[]) {
    stats<int> s;
	stats<double> d;
	stats<string> c;
	stats<char> t;

    //while(cin >> value) {
      //  s.push(value);
    //}

	s.push(9);
	s.push(20);
    s.print();

	d.push(4.6);
	d.push(17.8);
	d.print();

	c.push("terryl ");
	c.push("paula ");
	c.print();
}

template <typename T>
stats<T>::stats() {
    value = T();
    count = 0;
    sum = T();
}

template <typename T>
void stats<T>::print() {
     cout << "N = " << count << "\n";
     cout << "sum = " << sum << "\n";
	 cout << "\n";
}

template <typename T>
void stats<T>::push(T v) {
    sum += v;
    count++;
}
