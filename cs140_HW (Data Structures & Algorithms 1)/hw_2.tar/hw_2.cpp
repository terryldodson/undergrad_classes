#include <iostream>
using namespace std;

void list::push_front(const int &) { //insert function
	node *p = new node(din);

    p->data = din;
    p->next = head->next;
    head->next = p;

    N++;

}

void list::pop_front() { //erase function
	node *p;
    node *pp = findnode(i);

    p = head->next;
    pp = p->next;
    delete p;
    head->next = p;
    
    N--;
	
}

const int & list::front() {
	return head->next->data;
}
