select count(*) FROM Hotel;
