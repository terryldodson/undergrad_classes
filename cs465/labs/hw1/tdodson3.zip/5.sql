select price, type FROM Room WHERE hotelNo = 1;
