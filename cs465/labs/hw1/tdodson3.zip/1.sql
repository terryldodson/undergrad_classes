select * FROM Hotel WHERE city = 'london';
