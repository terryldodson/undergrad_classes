# I was confused on the reference to the hotel Booking table. I couldn't find that table.
# I was making posts on piazza but nobody was responding. Tried to figure it out on my own
# but kept on getting more confused
