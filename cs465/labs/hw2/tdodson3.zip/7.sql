#a. valid (I dont know what you mean by show so I'll just explain the mapping out. 
#RoomBookingCount is the parent or supertype query and hotelNo and roomNo are the subtypes 
#with tables of their own INSIDE of the RoomBookingCount table);
#b. invalid
#c. valid (RoomBoookingCount is still the parent or supertype query, and the * makes all 
#three hotelNo, roomNo, and bookingCount subtypes of the RoomBookingCount);
